Config = {}
Config.Locale = 'en'

Config.ReceiveMsg = true