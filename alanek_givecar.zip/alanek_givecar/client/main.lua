ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

TriggerEvent('chat:addSuggestion', '/givecar', 'Dodawanie pojazdu dla gracza', {
	{ name="id", help="ID gracza" },
    { name="model", help="Model pojazdu" },
    { name="tablica", help="Tablica rejestracyjna" }
})

RegisterNetEvent('raffi_addbryka:spawnVehicle')
AddEventHandler('raffi_addbryka:spawnVehicle', function(playerID, model, playerName, type, vehicleType)
	local playerPed = PlayerPedId()
	local coords    = GetEntityCoords(playerPed)
	local carExist  = false

	ESX.Game.SpawnVehicle(model, coords, 0.0, function(vehicle) --get vehicle info
		if DoesEntityExist(vehicle) then
			carExist = true
			SetEntityVisible(vehicle, false, false)
			SetEntityCollision(vehicle, false)
			
			local newPlate     = exports.esx_vehicleshop:GeneratePlate()
			local vehicleProps = ESX.Game.GetVehicleProperties(vehicle)
			vehicleProps.plate = newPlate
			TriggerServerEvent('raffi_addbryka:setVehicle', vehicleProps, playerID, model)
			ESX.Game.DeleteVehicle(vehicle)	
			if type ~= 'console' then
				ESX.ShowNotification('~g~Nadano pojazd! \n~r~Model: ~s~'..model..'\n~y~Tablica: '..newPlate..'\n~b~Gracz: '..playerName)
			else
				local msg = ('addCar: ' ..model.. ', plate: ' ..newPlate.. ', toPlayer: ' ..playerName)
				TriggerServerEvent('raffi_addbryka:printToConsole', msg)
			end				
		end		
	end)
	
	Wait(2000)
	if not carExist then
		if type ~= 'console' then
			ESX.ShowNotification('~r~Niepoprawny model! - '..model)
		else
			TriggerServerEvent('raffi_addbryka:printToConsole', "ERROR: "..model.." is an unknown vehicle model")
		end		
	end
end)

RegisterNetEvent('raffi_addbryka:spawnVehiclePlate')
AddEventHandler('raffi_addbryka:spawnVehiclePlate', function(playerID, model, plate, playerName, type, vehicleType)
	local playerPed = PlayerPedId()
	local coords    = GetEntityCoords(playerPed)
	local generatedPlate = string.upper(plate)
	local carExist  = false

	ESX.TriggerServerCallback('esx_shopvehicle:isPlateTaken', function (isPlateTaken)
		if not isPlateTaken then
			ESX.Game.SpawnVehicle(model, coords, 0.0, function(vehicle) --get vehicle info	
				if DoesEntityExist(vehicle) then
					carExist = true
					-- SetEntityVisible(vehicle, false, false)
					-- SetEntityCollision(vehicle, false)	
					
					local newPlate     = string.upper(plate)
					local vehicleProps = ESX.Game.GetVehicleProperties(vehicle)
					vehicleProps.plate = newPlate
					SetVehicleNumberPlateText(vehicle, newPlate)
					TriggerServerEvent('raffi_addbryka:setVehicle', vehicleProps, playerID, model)
					-- ESX.Game.DeleteVehicle(vehicle)
					if type ~= 'console' then
						ESX.ShowNotification('~g~Nadano pojazd! \n~r~Model: ~s~'..model..'\n~y~Tablica: '..newPlate..'\n~b~Gracz: '..playerName)
					else
						local msg = ('addCar: ' ..model.. ', plate: ' ..newPlate.. ', toPlayer: ' ..playerName)
						TriggerServerEvent('raffi_addbryka:printToConsole', msg)
					end				
				end
			end)
		else
			carExist = true
			if type ~= 'console' then
				ESX.ShowNotification('~r~Ktoś już ma tą tablice!')
			else
				local msg = ('ERROR: this plate is already been used on another vehicle')
				TriggerServerEvent('raffi_addbryka:printToConsole', msg)
			end					
		end
	end, generatedPlate)
	
	Wait(2000)
	if not carExist then
		if type ~= 'console' then
			ESX.ShowNotification('~r~Niepoprawny model! - '..model)
		else
			TriggerServerEvent('raffi_addbryka:printToConsole', "ERROR: "..model.." is an unknown vehicle model")
		end		
	end	
end)